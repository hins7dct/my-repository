# 股票数据爬虫系统

这是一个基于APScheduler、Celery和异步编程的分布式股票数据爬虫系统。

## 系统架构

整个系统由以下几个主要部分组成：

1. **APScheduler调度器**：负责定时触发爬虫任务
2. **Celery任务队列**：处理分布式任务调度和执行
3. **异步爬虫**：使用aiohttp库进行高效的并发爬取
4. **异步数据库操作**：使用aiomysql直接将爬取的数据写入MySQL数据库

## 目录结构

```
mycode/
├── crawler/                    # 爬虫模块
│   └── daily_k_line.py         # 异步日K线爬虫
├── db/                         # 数据库模块
│   ├── database.py             # 数据库连接
│   ├── models/                 # SQLAlchemy模型
│   └── create_tables.py        # 创建数据库表
├── celery_task/                # Celery任务模块
│   ├── celery_config.py        # Celery配置
│   ├── celery_tasks.py         # Celery任务定义
│   ├── scheduler.py            # APScheduler调度器
│   ├── worker.py               # Celery worker启动脚本
│   └── beat.py                 # Celery beat启动脚本
└── README.md                   # 说明文档
```

## 运行步骤

### 1. 安装依赖

```bash
pip install celery[redis] apscheduler aiohttp aiomysql
```

### 2. 启动Redis (Celery Broker)

```bash
redis-server
```

### 3. 创建数据库表

```bash
cd mycode
python db/create_tables.py
```

### 4. 启动系统

有两种方式运行系统：

方式一：使用Celery内置的beat调度器
```bash
# 启动Celery worker
cd mycode
python celery_task/worker.py

# 在另一个终端启动Celery beat
cd mycode
python celery_task/beat.py
```

方式二：使用APScheduler调度器
```bash
# 启动Celery worker
cd mycode
python celery_task/worker.py

# 在另一个终端启动APScheduler
cd mycode
python celery_task/scheduler.py
```

## 使用说明

### 添加新的爬虫任务

手动添加爬虫任务可以通过以下方式：

1. 直接调用Celery任务：
```python
from celery_task.celery_tasks import crawl_stock, add_stock_task

# 方式1：直接爬取股票并写入数据库
crawl_stock.delay(688288)

# 方式2：先添加到数据库，再由调度器处理
add_stock_task.delay(688288)
```

2. 添加数据库记录：
```sql
INSERT INTO tasks (stock_id, status) VALUES (688288, 'pending');
```

### 自定义爬虫

1. 在`crawler`目录下创建新的爬虫文件
2. 在`celery_tasks.py`中添加新的Celery任务
3. 在`scheduler.py`中添加相应的调度任务

## 配置说明

### 数据库配置

修改 `db/database.py` 和相应模块中的数据库配置：

```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'your_password',
    'db': 'your_database',
    'autocommit': True
}
```

### Celery配置

修改 `celery_task/celery_config.py` 中的配置：

```python
broker_url = 'redis://localhost:6379/0'
result_backend = 'redis://localhost:6379/1'
```

### 调度器配置

修改 `celery_task/scheduler.py` 中的调度时间：

```python
scheduler.add_job(
    add_stock_tasks,
    CronTrigger(hour=9, minute=0),
    name='每日股票数据爬取'
)
```

## 性能优化

1. 增加Celery worker数量：修改`worker.py`中的并发数
2. 调整异步爬虫并发量：修改`daily_k_line.py`中的并发限制
3. 优化数据库连接池：调整连接池大小和超时设置 