from apscheduler.schedulers.background import BackgroundScheduler
import time
from tasks.con_task import cron_con_stock
from tasks.eod_task import eod_cron
from tasks.report_task import report_cron
from tasks.daily_k_line_task import daily_k_line_cron

# 创建后台调度器
scheduler = BackgroundScheduler()

# 这一块是扫db拿任务
# 进入循环，投递任务
# 定义任务函数
def con_job():
    # 成分股
    print("定时任务执行：", time.strftime("%Y-%m-%d %H:%M:%S"))
    cron_con_stock.apply_async(args=['%3D%221%22'])

    # 添加定时任务，每天的13点30分触发任务
# scheduler.add_job(job, 'cron', hour=13, minute=30)
scheduler.add_job(con_job, 'interval', seconds=5)


def eod_job():
    # eod
    eod_cron.apply_async(args=['ST'])
scheduler.add_job(eod_job, 'interval', seconds=10)


# def report_job():
#     report_cron.apply_async(args=['', ''])
# scheduler.add_job(report_job, 'interval', seconds=10)
#
# def k_line_job():
#     daily_k_line_cron.apply_async(args=['', ''])
# scheduler.add_job(k_line_job, 'interval', seconds=10)

# 启动调度器
scheduler.start()

# 主线程等待一段时间后结束
time.sleep(20)

# 关闭调度器
scheduler.shutdown()

print("主线程结束")