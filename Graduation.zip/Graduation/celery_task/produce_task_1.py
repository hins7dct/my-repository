from tasks.daily_k_line_task import crawler
from tasks.con_task import send_msg

result1 = crawler.delay('www.baidu.com')
print(f"任务ID{result1.id}")
result2 = send_msg.delay('haohaohao')
print(f'任务ID{result2.id}')