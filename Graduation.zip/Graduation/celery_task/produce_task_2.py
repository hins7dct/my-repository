#produce_task_2.py
from tasks.daily_k_line_task import crawler
from tasks.con_task import send_msg
from datetime import datetime
#方式一 固定时间
v1 = datetime(2025, 3, 29, 23, 39, 00)
print(f"当前时间:{v1}")
v2 = datetime.utcfromtimestamp(v1.timestamp())
print(f"任务运行时间:{v2}")
result = crawler.apply_async(args=["定时任务-指定时间"], eta=v2)
print(f"任务ID{result.id}")

# 方式二
ctime = datetime.now()
utc_ctime = datetime.utcfromtimestamp(ctime.timestamp())
from datetime import timedelta
time_delay = timedelta(seconds=10)
task_time = utc_ctime + time_delay
#使用apply_async并设定时间
result = send_msg.apply_async(args=["定时任务-延时10秒"], eta=task_time)
print(result.id)