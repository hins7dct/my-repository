from .celery import app
import time
import os
os.environ['PYTHONPATH'] += 'D:/pythonProject/Graduation'
from mycode.crawler.con_stock import get_constituent_stock


@app.task
def cron_con_stock(type_):
    msg = get_constituent_stock(type_)
    return msg


# 这里后面会统一写一个发送消息到pulsar的方法，队列名字不一样
# 还会有一个pulsar消费者，消费每个消息队列的消息，解析入数据库
