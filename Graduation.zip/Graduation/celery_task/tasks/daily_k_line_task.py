from .celery import app
import os
os.environ['PYTHONPATH'] += 'D:/pythonProject/Graduation'
from mycode.crawler.daily_k_line import get_daily_hist


# 传到这里的任务可能是好几条db的记录
# 执行错误的任务后续单独时间调度
@app.task
def daily_k_line_cron(stock_id, task_type):
    if task_type == 'daily_k_line':
        msg = get_daily_hist(stock_id, klt=101)
    elif task_type == '5mins_k_line':
        msg = get_daily_hist(stock_id, klt=5)
    else:
        msg = get_daily_hist(stock_id, klt=30)
    return msg
