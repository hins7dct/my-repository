from __future__ import absolute_import
import sys
from pathlib import Path

# 获取项目根目录路径
project_root = Path(__file__).parent.parent.absolute()
sys.path.insert(0, str(project_root))
from celery import Celery
from datetime import timedelta

broker_url = 'redis://127.0.0.1:6379/1'
backend_url = 'redis://127.0.0.1:6379/2'
app = Celery('celery_demo',
             broker=broker_url,
             backend=backend_url,
             include=['tasks.con_task',
                      'tasks.daily_k_line_task',
                      'tasks.eod_task',
                      'tasks.report_task'])

# 配置
app.conf.timezone = 'Asia/Shanghai'
app.conf.enable_utc = False
app.conf.beat_schedule = {
    'whatever': {
        'task': 'tasks.task01.crawler',
        'schedule': timedelta(seconds=10),
        'args': ('张三',)
    }
}
