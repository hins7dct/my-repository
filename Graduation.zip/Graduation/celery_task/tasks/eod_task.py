from .celery import app
import os
os.environ['PYTHONPATH'] += 'D:/pythonProject/Graduation'
from mycode.crawler.eod import get_eod


# 传到这里的任务可能是好几条db的记录
# 执行错误的任务后续单独时间调度
@app.task
def eod_cron(type_):
    msg = get_eod(type_)
    return msg


# eod 分A股和ST板块，传入A/ST就可以，直接两个任务就行
