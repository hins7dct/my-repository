from .celery import app
import os
os.environ['PYTHONPATH'] += 'D:/pythonProject/Graduation'
from mycode.crawler.report import get_report


# 传到这里的任务可能是好几条db的记录
# 执行错误的任务后续单独时间调度
@app.task
def report_cron(stock_id, report_type):
    msg = get_report(stock_id, report_type)
    return msg

# 从db里拿任务记录，取stockid ，reporttype和status正常的
# 做任务这里需要日志记录，任务id，stock id，report type，结果，时间，倘若失败，失败原因给出