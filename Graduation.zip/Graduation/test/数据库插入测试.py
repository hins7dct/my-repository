# 全部股票信息插入，插入测试完成
import os
import sys
import asyncio
from sqlalchemy import insert, text

# 添加项目根目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '../..'))
sys.path.insert(0, project_root)

from mycode.db.database import SessionLocal, engine
from mycode.db.models.all_stocks import StocksInfo


async def import_stocks_from_file(file_path):
    """
    从文本文件导入股票数据到数据库
    :param file_path: 文本文件路径
    """
    if not os.path.exists(file_path):
        print(f"错误: 文件 {file_path} 不存在!")
        return

    print(f"开始从 {file_path} 导入股票数据...")

    # 尝试不同的编码读取文件
    encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030', 'cp936', 'latin1']
    lines = []

    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                lines = f.readlines()
                print(f"成功使用 {encoding} 编码读取文件，共读取 {len(lines)} 行")
                break
        except UnicodeDecodeError:
            print(f"尝试 {encoding} 编码失败，尝试下一种编码...")
            continue

    if not lines:
        print("无法使用任何已知编码读取文件，请检查文件格式")
        return

    # 准备导入数据
    stock_data = []
    for line in lines:
        line = line.strip()
        if not line:
            continue

        # 尝试处理不同的分隔符
        for separator in [',', '\t', ' ', ';']:
            parts = line.split(separator)
            if len(parts) >= 2:
                stock_id = parts[0].strip()
                stock_name = parts[1].strip()

                # 检查股票代码有效性
                if stock_id.isdigit() and len(stock_id) <= 10:
                    stock_data.append({
                        'stockId': stock_id,
                        'name': stock_name
                    })
                    break

    print(f"从文件中读取了 {len(stock_data)} 条股票数据")

    # 显示前几条数据作为示例
    if stock_data:
        print("数据示例:")
        for i, stock in enumerate(stock_data[:5]):
            print(f"  {i + 1}. {stock['stockId']} - {stock['name']}")
        if len(stock_data) > 5:
            print(f"  ... 还有 {len(stock_data) - 5} 条数据")
    else:
        print("警告：没有找到有效的股票数据！")
        return

    # 使用SQLAlchemy导入数据
    with SessionLocal() as session:
        try:
            # 查询现有数据
            print("查询现有股票数据...")
            existing_stock_ids = set()
            for stock in session.query(StocksInfo.stockId).all():
                existing_stock_ids.add(stock[0])

            print(f"数据库中已有 {len(existing_stock_ids)} 条股票记录")

            # 过滤出新数据
            new_stock_data = [data for data in stock_data if data['stockId'] not in existing_stock_ids]

            if not new_stock_data:
                print("没有新的股票数据需要导入")
                return

            # 批量插入新数据
            print(f"正在导入 {len(new_stock_data)} 条新股票数据...")

            # 采用更直接的SQL插入方式
            for data in new_stock_data:
                try:
                    session.execute(
                        text("INSERT INTO stocks_info (stockId, name) VALUES (:stockId, :name)"),
                        data
                    )
                    print(f"插入记录: {data['stockId']} - {data['name']}")
                except Exception as e:
                    print(f"插入记录 {data['stockId']} 失败: {e}")

            # 提交事务
            print("提交事务...")
            session.commit()
            print("导入完成!")

        except Exception as e:
            session.rollback()
            print(f"导入数据时出错: {e}")
            import traceback
            traceback.print_exc()


def main():
    """程序入口"""
    # 获取当前脚本路径
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # 尝试在不同位置查找文件
    possible_locations = [
        'all_stock_data.txt',  # 当前目录
        os.path.join(script_dir, 'all_stock_data.txt'),  # 脚本所在目录
        os.path.join(script_dir, '..', 'all_stock_data.txt'),  # 上级目录
        os.path.join(project_root, 'all_stock_data.txt'),  # 项目根目录
    ]

    # 查找文件
    file_path = None
    for location in possible_locations:
        if os.path.exists(location):
            file_path = location
            print(f"找到文件: {location}")
            break

    if file_path is None:
        print("请输入all_stock_data.txt文件的完整路径:")
        file_path = input().strip()
        if not os.path.exists(file_path):
            print(f"错误: 文件 {file_path} 不存在!")
            return

    # 运行异步导入函数
    asyncio.run(import_stocks_from_file(file_path))

    # 打印导入后的数据统计
    with SessionLocal() as session:
        count = session.query(StocksInfo).count()
        print(f"数据库中现有 {count} 条股票记录")


if __name__ == "__main__":
    main()