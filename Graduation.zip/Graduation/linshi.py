import aiohttp
import asyncio
import json
import platform
from typing import Dict, List

if platform.system() == 'Windows':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# 全局并发控制
CONCURRENCY_LIMIT = 5
semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)


async def get_eod_async(fs: str = 'A') -> Dict:
    """
    异步获取股票日行情数据
    :param fs: 板块类型 ('A'-沪深A股 'ST'-ST板块)
    :return: 包含行情数据的字典
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) '
                      'AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/110.0.0.0 Mobile Safari/537.36'
    }

    # 确定筛选条件
    filter_map = {
        'A': 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048',
        'ST': 'm:0+f:4,m:1+f:4'
    }
    filter_ = filter_map.get(fs, 'A')  # 默认返回沪深A股

    # 分页获取全部数据
    page_num = 1
    page_size = 100  # 每页获取的股票数量
    all_stocks = []
    has_more = True

    while has_more:
        url = (
            'https://push2.eastmoney.com/api/qt/clist/get?'
            'np=1&fltt=1&invt=2&cb=data&'
            f'fs={filter_}&'
            'fields=f12,f13,f14,f1,f2,f4,f3,f152,f5,f6,f7,f15,f18,f16,f17,f10,f8,f9,f23&'
            f'fid=f3&pn={page_num}&pz={page_size}&po=1&dect=1&'
            'ut=fa5fd1943c7b386f172d6893dbfba10b&'
            'wbp2u=|0|0|0|web&_=1742111940386'
        )

        try:
            async with semaphore:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers) as response:
                        response.raise_for_status()
                        res = await response.text()
                        json_data = json.loads(res[5:-2])  # 去除JSONP包装

                        # 检查是否有数据
                        if json_data.get('data') is None or not json_data.get('data', {}).get('diff'):
                            has_more = False
                        else:
                            # 添加当前页的数据
                            stocks = json_data.get('data', {}).get('diff', [])
                            all_stocks.extend(stocks)
                            print(f"成功获取第 {page_num} 页数据，共 {len(stocks)} 条记录")
                            page_num += 1

        except aiohttp.ClientError as e:
            print(f"[{fs}] 页 {page_num} 网络请求失败: {str(e)}")
            has_more = False
        except json.JSONDecodeError as e:
            print(f"[{fs}] 页 {page_num} JSON解析失败: {str(e)}")
            has_more = False
        except Exception as e:
            print(f"[{fs}] 页 {page_num} 未知错误: {str(e)}")
            has_more = False

    # 返回组合的结果
    return {
        'data': {
            'diff': all_stocks
        },
        'total': len(all_stocks)
    }


async def get_multi_eod(fs_list: List[str]) -> Dict[str, List]:
    """
    并发获取多个板块行情数据
    :param fs_list: 板块类型列表 (如 ['A', 'ST'])
    :return: 按板块分类的行情数据字典
    """
    tasks = [get_eod_async(fs) for fs in fs_list]
    results = await asyncio.gather(*tasks)

    # 整理数据结构
    final_data = {}
    for fs, result in zip(fs_list, results):
        final_data[fs] = result.get('data', {}).get('diff', [])
    return final_data


async def main():
    # 并发获取沪深A股和ST板块数据
    all_data = await get_eod_async('A')
    return all_data

    # 结果统计
    # for fs_type, stocks in all_data.items():
    #     print(f"{'沪深A股' if fs_type == 'A' else 'ST板块'} 包含 {len(stocks)} 只股票")

    # 示例：展示前3只沪深A股
    # print("\n沪深A股样例数据:")
    # for stock in all_data['A'][:3]:
    #     print(f"{stock['f14']} ({stock['f12']}) 最新价: {stock['f2']}")


if __name__ == '__main__':
    # print(len(asyncio.run(main()).get('data', {}).get('diff', [])))
    # 把A股的所有f12,f14数据弄出来，写入文件里
    # print(asyncio.run(main()))
    with open('all_stock_data.txt', 'w') as f:
        for i in asyncio.run(main()).get('data', {}).get('diff', []):
            f.write(f"{i['f12']},{i['f14']}\n")