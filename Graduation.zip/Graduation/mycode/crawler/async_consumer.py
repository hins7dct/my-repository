# async_consumer.py
import asyncio
import json
import logging
import aiomysql
import pulsar
import time
from concurrent.futures import ThreadPoolExecutor

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 数据库配置
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Letgo.Al6',
    'db': 'test_insert',
    'autocommit': True
}

# Pulsar配置
PULSAR_URL = 'pulsar://localhost:6650'
PULSAR_TOPIC = 'stock_data'
CONSUMER_NAME = 'stock_data_consumer'

# 线程池大小，用于包装非异步的Pulsar消费者
MAX_WORKERS = 5


# 初始化数据库连接池
async def init_db_pool():
    try:
        pool = await aiomysql.create_pool(**DB_CONFIG)
        logger.info("数据库连接池初始化成功")
        return pool
    except Exception as e:
        logger.error(f"数据库连接池初始化失败: {e}")
        raise


# 异步写入数据库
async def insert_stock_data(pool, data):
    """
    异步将股票数据写入数据库
    """
    try:
        # 提取数据
        stock_id = data['stock_id']
        task_id = data['task_id']
        kline_data = data['data']

        # 获取股票每日K线数据
        if 'data' in kline_data and 'klines' in kline_data['data']:
            klines = kline_data['data']['klines']

            async with pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    for kline in klines:
                        # 假设每条K线数据格式为: "日期,开盘价,收盘价,最高价,最低价,成交量,成交额,振幅,涨跌幅,涨跌额,换手率"
                        values = kline.split(',')

                        # 检查数据格式
                        if len(values) < 10:
                            logger.warning(f"数据格式不正确: {kline}")
                            continue

                        # 提取字段
                        date = values[0]
                        open_price = values[1]
                        close_price = values[2]
                        high_price = values[3]
                        low_price = values[4]
                        volume = values[5]
                        amount = values[6]

                        # 插入数据库
                        # 假设有一个daily_k_line表存储股票每日K线数据
                        await cursor.execute(
                            """
                            INSERT INTO daily_k_line 
                            (stock_id, trade_date, open_price, close_price, high_price, low_price, volume, amount, task_id) 
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                            ON DUPLICATE KEY UPDATE 
                            open_price = VALUES(open_price),
                            close_price = VALUES(close_price),
                            high_price = VALUES(high_price),
                            low_price = VALUES(low_price),
                            volume = VALUES(volume),
                            amount = VALUES(amount),
                            task_id = VALUES(task_id)
                            """,
                            (stock_id, date, open_price, close_price, high_price, low_price, volume, amount, task_id)
                        )

            logger.info(f"股票 {stock_id} 的K线数据已成功写入数据库")
            return True
        else:
            logger.warning(f"股票 {stock_id} 的K线数据格式不正确")
            return False
    except Exception as e:
        logger.error(f"写入数据库失败: {e}")
        return False


# 消费者函数 - 在线程池中运行
def consume_messages(message_queue):
    """
    Pulsar消费者，接收消息并放入消息队列
    """
    client = pulsar.Client(PULSAR_URL)
    consumer = client.subscribe(PULSAR_TOPIC, CONSUMER_NAME)

    logger.info(f"Pulsar消费者已启动，订阅主题: {PULSAR_TOPIC}")

    try:
        while True:
            try:
                # 接收消息，超时10秒
                msg = consumer.receive(timeout_millis=10000)

                # 解析消息
                data = json.loads(msg.data())

                # 放入队列
                message_queue.put_nowait(data)

                # 确认消息
                consumer.acknowledge(msg)

                logger.debug(f"收到消息: {msg.message_id()}")
            except pulsar.Timeout:
                # 超时，继续等待
                continue
            except Exception as e:
                logger.error(f"处理消息失败: {e}")
                # 异常处理，不确认消息，让它重新投递
                try:
                    consumer.negative_acknowledge(msg)
                except:
                    pass
    finally:
        consumer.close()
        client.close()
        logger.info("Pulsar消费者已关闭")


# 异步处理消息队列
async def process_message_queue(pool, message_queue):
    """
    异步处理消息队列中的消息
    """
    while True:
        try:
            # 从队列获取消息
            data = await message_queue.get()

            # 异步写入数据库
            success = await insert_stock_data(pool, data)

            if success:
                logger.info(f"消息处理成功: {data.get('task_id')}")
            else:
                logger.warning(f"消息处理失败: {data.get('task_id')}")

            # 标记任务完成
            message_queue.task_done()

        except asyncio.CancelledError:
            # 取消任务
            break
        except Exception as e:
            logger.error(f"处理消息队列异常: {e}")
            await asyncio.sleep(1)  # 发生异常时暂停一段时间


# 主函数
async def main():
    # 初始化数据库连接池
    pool = await init_db_pool()

    # 创建消息队列
    message_queue = asyncio.Queue()

    # 创建线程池
    executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)

    # 在线程池中启动Pulsar消费者
    loop = asyncio.get_event_loop()
    consumer_future = loop.run_in_executor(executor, consume_messages, message_queue)

    # 创建多个异步处理器
    processors = []
    for i in range(3):  # 创建3个处理器
        processor = asyncio.create_task(process_message_queue(pool, message_queue))
        processors.append(processor)

    try:
        # 等待消费者完成（实际上它会一直运行，直到发生异常或被取消）
        await consumer_future
    except KeyboardInterrupt:
        logger.info("收到中断信号，程序退出")
    except Exception as e:
        logger.error(f"程序运行异常: {e}")
    finally:
        # 取消所有处理器
        for processor in processors:
            processor.cancel()

        # 等待所有处理器关闭
        await asyncio.gather(*processors, return_exceptions=True)

        # 关闭数据库连接池
        pool.close()
        await pool.wait_closed()

        # 关闭线程池
        executor.shutdown(wait=True)

        logger.info("程序已退出")


if __name__ == "__main__":
    asyncio.run(main())