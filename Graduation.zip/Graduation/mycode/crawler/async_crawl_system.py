# async_crawl_system.py
import asyncio
import json
import logging
import aiomysql
import pulsar
from daily_k_line import get_daily_hist, get_multi_stocks

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 数据库配置
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Letgo.Al6',
    'db': 'test_insert',
    'autocommit': True
}

# Pulsar配置
PULSAR_URL = 'pulsar://localhost:6650'
PULSAR_TOPIC = 'stock_data'


# 初始化数据库连接池
async def init_db_pool():
    try:
        pool = await aiomysql.create_pool(**DB_CONFIG)
        logger.info("数据库连接池初始化成功")
        return pool
    except Exception as e:
        logger.error(f"数据库连接池初始化失败: {e}")
        raise


# 异步获取爬虫任务
async def fetch_tasks(pool, limit=10):
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cursor:
            # 假设有一个tasks表，存储待爬取的股票任务
            await cursor.execute(
                "SELECT * FROM tasks WHERE status = 'pending' LIMIT %s",
                (limit,)
            )
            tasks = await cursor.fetchall()

            if tasks:
                # 更新任务状态为处理中
                task_ids = [task['id'] for task in tasks]
                placeholders = ','.join(['%s'] * len(task_ids))
                await cursor.execute(
                    f"UPDATE tasks SET status = 'processing' WHERE id IN ({placeholders})",
                    task_ids
                )

            return tasks


# 异步发送数据到Pulsar
async def send_to_pulsar(data):
    # 由于Pulsar Python客户端不是异步的，我们使用run_in_executor在线程池中执行
    loop = asyncio.get_event_loop()

    def _send_data():
        try:
            client = pulsar.Client(PULSAR_URL)
            producer = client.create_producer(PULSAR_TOPIC)
            producer.send(json.dumps(data).encode('utf-8'))
            producer.flush()
            client.close()
            return True
        except Exception as e:
            logger.error(f"发送数据到Pulsar失败: {e}")
            return False

    return await loop.run_in_executor(None, _send_data)


# 更新任务状态
async def update_task_status(pool, task_id, status, result=None):
    async with pool.acquire() as conn:
        async with conn.cursor() as cursor:
            if result:
                await cursor.execute(
                    "UPDATE tasks SET status = %s, result = %s WHERE id = %s",
                    (status, json.dumps(result), task_id)
                )
            else:
                await cursor.execute(
                    "UPDATE tasks SET status = %s WHERE id = %s",
                    (status, task_id)
                )


# 处理单个任务
async def process_task(pool, task):
    try:
        # 从任务中获取股票ID
        stock_id = task['stock_id']
        logger.info(f"开始处理任务: {task['id']}, 股票ID: {stock_id}")

        # 异步爬取股票数据
        data = await get_daily_hist(stockId=stock_id)

        # 构建结果数据
        result = {
            'task_id': task['id'],
            'stock_id': stock_id,
            'data': data
        }

        # 发送数据到Pulsar
        send_success = await send_to_pulsar(result)

        # 更新任务状态
        if send_success:
            await update_task_status(pool, task['id'], 'completed', result)
            logger.info(f"任务 {task['id']} 处理完成")
        else:
            await update_task_status(pool, task['id'], 'failed')
            logger.error(f"任务 {task['id']} 发送到Pulsar失败")

    except Exception as e:
        logger.error(f"处理任务 {task['id']} 失败: {e}")
        await update_task_status(pool, task['id'], 'failed')


# 主循环
async def main():
    # 初始化数据库连接池
    pool = await init_db_pool()

    try:
        while True:
            # 获取待处理任务
            tasks = await fetch_tasks(pool)

            if not tasks:
                logger.info("没有待处理任务，等待5秒...")
                await asyncio.sleep(5)
                continue

            logger.info(f"获取到 {len(tasks)} 个待处理任务")

            # 并发处理所有任务
            process_tasks = [process_task(pool, task) for task in tasks]
            await asyncio.gather(*process_tasks)

            # 控制爬取频率
            await asyncio.sleep(1)

    except KeyboardInterrupt:
        logger.info("收到中断信号，程序退出")
    except Exception as e:
        logger.error(f"程序运行异常: {e}")
    finally:
        # 关闭数据库连接池
        pool.close()
        await pool.wait_closed()
        logger.info("数据库连接池已关闭")


# 消费者示例 (可以在单独的文件中实现)
def pulsar_consumer():
    """
    Pulsar消费者，接收消息并写入数据库
    这部分可以单独运行
    """
    client = pulsar.Client(PULSAR_URL)
    consumer = client.subscribe(PULSAR_TOPIC, 'stock_data_consumer')

    try:
        while True:
            msg = consumer.receive()
            try:
                # 处理消息
                data = json.loads(msg.data())
                print(f"收到消息: {data}")

                # 在这里实现数据库写入逻辑
                # ...

                # 确认消息
                consumer.acknowledge(msg)
            except Exception as e:
                # 处理失败，消息会被重新投递
                consumer.negative_acknowledge(msg)
                print(f"处理消息失败: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    # 运行异步爬虫系统
    asyncio.run(main())

    # 消费者在单独的进程中运行
    # pulsar_consumer()