from abc import ABC, abstractmethod
from typing import Any


class BaseParser(ABC):
    @abstractmethod
    def parse(self, raw_data) -> Any:
        """解析原始数据（如HTML/JSON），返回结构化数据"""
        pass



