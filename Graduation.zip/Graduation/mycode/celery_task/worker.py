from celery_tasks import app

if __name__ == '__main__':
    # 启动Celery worker
    app.worker_main(['worker', '--loglevel=info', '-c', '4'])  # 使用4个并发worker'