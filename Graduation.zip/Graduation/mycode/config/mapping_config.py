# 不太好解析，因为列名并没有直接打出来 全是f11之类的
# f1:不知道 f2最新价，然后需要/100 f3涨跌幅/100 + % f4涨跌额/100 f5成交量/10000万 f6成交额/100000000亿 f7振幅/100 + % f8换手率/100 + %
# f9市盈率/100 + % f10 量比/100 f12股票代码 f13股票所属市场类型 f14 名称 f15 f16 f17 最高最低今开 f18昨收 都是/100 f23市净率/100 + %  f152不知道
# f13 1：沪市 2：深市  116：港股  105：美股

EOD_MAPPING_FIELD = {
    "f1": "ranking",
    "f2": "latest_price",
    "f3": "change_pct",
    "f4": "change_amt",
    "f5": "volume",
    "f6": "turnover",
    "f7": "amplitude",
    "f8": "turnover_rate",
    "f9": "pe_ratio",
    "f10": "volume_ratio",
    "f12": "symbol",
    "f13": "market_type",
    "f14": "name",
    "f15": "high",
    "f16": "low",
    "f17": "open",
    "f18": "prev_close",
    "f152": "f152"  # 不知道，暂时不处理
}

CON_STK_MAPPING_FIELD = {
    "f2": "最新价",
    "f3": "涨跌幅",
}
