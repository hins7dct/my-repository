from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base

# 后面可能加一下是否ST这个字段，现在可以不用
class StocksInfo(Base):
    __tablename__ = 'stocks_info'
    __table_args__ = (
        Index('idx_stockId', 'stockId', 'name'),  # 高频查询优化
        {'comment': '股票信息表'}
    )
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')
    stockId = Column(String(10), nullable=False, unique=True, comment='证券简码')
    name = Column(String(50), nullable=False, comment='证券简称')


"""
CREATE TABLE stocks_info (
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    stockId VARCHAR(10) NOT NULL COMMENT '证券简码',
    name VARCHAR(50) NOT NULL COMMENT '证券简称',
    PRIMARY KEY (id),
    UNIQUE KEY (stockId),
    INDEX idx_stockId (stockId, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='股票信息表';
"""