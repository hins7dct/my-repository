from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base


class CashFlowStatement(Base):
    __tablename__ = 'cash_flow_statement'
    __table_args__ = (
        Index('idx_cashflow_security', 'SECUCODE', 'REPORT_DATE'),  # 高频查询优化
        {'comment': '企业现金流量表'}
    )
    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')

    # 证券基础信息
    SECUCODE = Column(String(20), nullable=False, comment='证券全代码（含交易所后缀）')
    SECURITY_CODE = Column(String(10), nullable=False, comment='证券简码')
    INDUSTRY_CODE = Column(String(10), nullable=False, comment='行业编码')
    ORG_CODE = Column(String(20), nullable=False, comment='组织机构代码')
    SECURITY_NAME_ABBR = Column(String(50), nullable=False, comment='证券简称')
    INDUSTRY_NAME = Column(String(30), nullable=False, comment='行业名称')
    MARKET = Column(String(10), nullable=False, comment='上市市场标识（kcb=科创板）')
    SECURITY_TYPE_CODE = Column(String(10), nullable=False, comment='证券类型编码')
    TRADE_MARKET_CODE = Column(String(20), nullable=False, comment='交易市场编码')

    # 报告属性
    DATE_TYPE_CODE = Column(String(3), nullable=False, comment='日期类型编码（004=季报）')
    REPORT_TYPE_CODE = Column(String(3), nullable=False, comment='报告类型编码（001=合并报表）')
    DATA_STATE = Column(String(2), nullable=False, comment='数据状态（2=已审计）')
    NOTICE_DATE = Column(DateTime, nullable=False, comment='公告发布时间')
    REPORT_DATE = Column(DateTime, nullable=False, comment='报告期截止日')

    # 现金流量核心指标（单位：元）
    NETCASH_OPERATE = Column(BIGINT(20), comment='经营活动产生的现金流量净额')
    NETCASH_OPERATE_RATIO = Column(DECIMAL(20, 4), comment='经营活动现金流净额占比(%)')
    SALES_SERVICES = Column(BIGINT(20), comment='销售商品、提供劳务收到的现金')
    SALES_SERVICES_RATIO = Column(DECIMAL(20, 4), comment='销售商品现金占比(%)')
    PAY_STAFF_CASH = Column(BIGINT(20), comment='支付给职工以及为职工支付的现金')
    PSC_RATIO = Column(DECIMAL(20, 4), comment='职工现金支付占比(%)')
    NETCASH_INVEST = Column(BIGINT(20), comment='投资活动产生的现金流量净额')
    NETCASH_INVEST_RATIO = Column(DECIMAL(20, 4), comment='投资活动现金流净额占比(%)')
    RECEIVE_INVEST_INCOME = Column(BIGINT(20), comment='取得投资收益收到的现金')
    RII_RATIO = Column(DECIMAL(20, 4), comment='投资收益现金占比(%)')
    CONSTRUCT_LONG_ASSET = Column(BIGINT(20), comment='购建固定资产等支付的现金')
    CLA_RATIO = Column(DECIMAL(20, 4), comment='长期资产投资现金占比(%)')
    NETCASH_FINANCE = Column(BIGINT(20), comment='筹资活动产生的现金流量净额')
    NETCASH_FINANCE_RATIO = Column(DECIMAL(20, 4), comment='筹资活动现金流净额占比(%)')
    CCE_ADD = Column(BIGINT(20), comment='现金及现金等价物净增加额')
    CCE_ADD_RATIO = Column(DECIMAL(20, 4), comment='现金等价物增加占比(%)')

    # 可空字段（特殊行业或可选指标）
    CUSTOMER_DEPOSIT_ADD = Column(BIGINT(20), nullable=True, comment='客户存款净增加额（金融行业）')
    CDA_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='客户存款增加占比(%)')
    DEPOSIT_IOFI_OTHER = Column(BIGINT(20), nullable=True, comment='存放同业及其他金融机构款项')
    DIO_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='存放同业款项占比(%)')
    LOAN_ADVANCE_ADD = Column(BIGINT(20), nullable=True, comment='发放贷款及垫款净增加额')
    LAA_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='贷款及垫款增加占比(%)')
    RECEIVE_INTEREST_COMMISSION = Column(BIGINT(20), nullable=True, comment='收取利息、手续费及佣金')
    RIC_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='利息佣金收入占比(%)')
    INVEST_PAY_CASH = Column(BIGINT(20), nullable=True, comment='投资支付的现金')
    IPC_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='投资支付现金占比(%)')
    BEGIN_CCE = Column(BIGINT(20), nullable=True, comment='期初现金及现金等价物余额')
    BEGIN_CCE_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='期初现金占比(%)')
    END_CCE = Column(BIGINT(20), nullable=True, comment='期末现金及现金等价物余额')
    END_CCE_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='期末现金占比(%)')
    RECEIVE_ORIGIC_PREMIUM = Column(BIGINT(20), nullable=True, comment='原保险合同保费收入（保险行业）')
    ROP_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='原保险保费收入占比(%)')
    PAY_ORIGIC_COMPENSATE = Column(BIGINT(20), nullable=True, comment='支付原保险合同赔付款项')
    POC_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='保险赔付支出占比(%)')

    # 系统字段
    gmt_create = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"), comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='数据更新时间')

    def add(self):
        pass


"""
CREATE TABLE cash_flow_statement (
    -- 主键
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    
    -- 证券基础信息
    SECUCODE VARCHAR(20) NOT NULL COMMENT '证券全代码（含交易所后缀）',
    SECURITY_CODE VARCHAR(10) NOT NULL COMMENT '证券简码',
    INDUSTRY_CODE VARCHAR(10) NOT NULL COMMENT '行业编码',
    ORG_CODE VARCHAR(20) NOT NULL COMMENT '组织机构代码',
    SECURITY_NAME_ABBR VARCHAR(50) NOT NULL COMMENT '证券简称',
    INDUSTRY_NAME VARCHAR(30) NOT NULL COMMENT '行业名称',
    MARKET VARCHAR(10) NOT NULL COMMENT '上市市场标识（kcb=科创板）',
    SECURITY_TYPE_CODE VARCHAR(10) NOT NULL COMMENT '证券类型编码',
    TRADE_MARKET_CODE VARCHAR(20) NOT NULL COMMENT '交易市场编码',
    
    -- 报告属性
    DATE_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '日期类型编码（004=季报）',
    REPORT_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '报告类型编码（001=合并报表）',
    DATA_STATE VARCHAR(2) NOT NULL COMMENT '数据状态（2=已审计）',
    NOTICE_DATE DATETIME NOT NULL COMMENT '公告发布时间',
    REPORT_DATE DATETIME NOT NULL COMMENT '报告期截止日',
    
    -- 现金流量核心指标（单位：元）
    NETCASH_OPERATE BIGINT(20) COMMENT '经营活动产生的现金流量净额',
    NETCASH_OPERATE_RATIO DECIMAL(20,4) COMMENT '经营活动现金流净额占比(%)',
    SALES_SERVICES BIGINT(20) COMMENT '销售商品、提供劳务收到的现金',
    SALES_SERVICES_RATIO DECIMAL(20,4) COMMENT '销售商品现金占比(%)',
    PAY_STAFF_CASH BIGINT(20) COMMENT '支付给职工以及为职工支付的现金',
    PSC_RATIO DECIMAL(20,4) COMMENT '职工现金支付占比(%)',
    NETCASH_INVEST BIGINT(20) COMMENT '投资活动产生的现金流量净额',
    NETCASH_INVEST_RATIO DECIMAL(20,4) COMMENT '投资活动现金流净额占比(%)',
    RECEIVE_INVEST_INCOME BIGINT(20) COMMENT '取得投资收益收到的现金',
    RII_RATIO DECIMAL(20,4) COMMENT '投资收益现金占比(%)',
    CONSTRUCT_LONG_ASSET BIGINT(20) COMMENT '购建固定资产等支付的现金',
    CLA_RATIO DECIMAL(20,4) COMMENT '长期资产投资现金占比(%)',
    NETCASH_FINANCE BIGINT(20) COMMENT '筹资活动产生的现金流量净额',
    NETCASH_FINANCE_RATIO DECIMAL(20,4) COMMENT '筹资活动现金流净额占比(%)',
    CCE_ADD BIGINT(20) COMMENT '现金及现金等价物净增加额',
    CCE_ADD_RATIO DECIMAL(20,4) COMMENT '现金等价物增加占比(%)',
    
    -- 可空字段（特殊行业或可选指标）
    CUSTOMER_DEPOSIT_ADD BIGINT(20) NULL COMMENT '客户存款净增加额（金融行业）',
    CDA_RATIO DECIMAL(20,4) NULL COMMENT '客户存款增加占比(%)',
    DEPOSIT_IOFI_OTHER BIGINT(20) NULL COMMENT '存放同业及其他金融机构款项',
    DIO_RATIO DECIMAL(20,4) NULL COMMENT '存放同业款项占比(%)',
    LOAN_ADVANCE_ADD BIGINT(20) NULL COMMENT '发放贷款及垫款净增加额',
    LAA_RATIO DECIMAL(20,4) NULL COMMENT '贷款及垫款增加占比(%)',
    RECEIVE_INTEREST_COMMISSION BIGINT(20) NULL COMMENT '收取利息、手续费及佣金',
    RIC_RATIO DECIMAL(20,4) NULL COMMENT '利息佣金收入占比(%)',
    INVEST_PAY_CASH BIGINT(20) NULL COMMENT '投资支付的现金',
    IPC_RATIO DECIMAL(20,4) NULL COMMENT '投资支付现金占比(%)',
    BEGIN_CCE BIGINT(20) NULL COMMENT '期初现金及现金等价物余额',
    BEGIN_CCE_RATIO DECIMAL(20,4) NULL COMMENT '期初现金占比(%)',
    END_CCE BIGINT(20) NULL COMMENT '期末现金及现金等价物余额',
    END_CCE_RATIO DECIMAL(20,4) NULL COMMENT '期末现金占比(%)',
    RECEIVE_ORIGIC_PREMIUM BIGINT(20) NULL COMMENT '原保险合同保费收入（保险行业）',
    ROP_RATIO DECIMAL(20,4) NULL COMMENT '原保险保费收入占比(%)',
    PAY_ORIGIC_COMPENSATE BIGINT(20) NULL COMMENT '支付原保险合同赔付款项',
    POC_RATIO DECIMAL(20,4) NULL COMMENT '保险赔付支出占比(%)',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据更新时间',
    
    -- 索引
    PRIMARY KEY (id),
    INDEX idx_cashflow_security (SECUCODE, REPORT_DATE),
    INDEX idx_report_date (REPORT_DATE),
    INDEX idx_industry (INDUSTRY_CODE)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='企业现金流量表';
"""
