import sqlalchemy
from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base



class ConstituentStock(Base):
    __tablename__ = 'constituent_stocks'
    __table_args__ = (
        Index('idx_security_type', 'SECUCODE', 'TYPE'),  # 证券代码+类型复合索引
        Index('idx_industry', 'INDUSTRY'),  # 行业分类索引
        {'comment': '指数成分股数据表'}
    )

    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')

    # 证券基础信息
    SECUCODE = Column(String(20), nullable=False, comment='证券全代码（交易所后缀）')
    SECURITY_CODE = Column(String(10), nullable=False, comment='证券简码')
    TYPE = Column(String(2), nullable=False, comment='成分股类型（1=普通股）')
    SECURITY_NAME_ABBR = Column(String(50), nullable=False, comment='证券简称')

    # 行情数据
    CLOSE_PRICE = Column(DECIMAL(12, 4), comment='收盘价（元）')


    # 公司特征
    INDUSTRY = Column(String(20), comment='所属行业')
    REGION = Column(String(10), comment='所属地区')
    WEIGHT = Column(DECIMAL(8, 4), comment='指数权重（%）')

    # 财务指标
    EPS = Column(DECIMAL(8, 4), comment='每股收益（元）')
    BPS = Column(DECIMAL(12, 4), comment='每股净资产（元）')
    ROE = Column(DECIMAL(8, 4), nullable=True, comment='净资产收益率%（可能为空）')

    # 股本数据（单位：亿股）
    TOTAL_SHARES = Column(DECIMAL(18, 4), comment='总股本')
    FREE_SHARES = Column(DECIMAL(18, 4), comment='流通股本')
    FREE_CAP = Column(DECIMAL(18, 4), comment='流通市值（亿元）')

    latest_price = Column(DECIMAL(12, 4), comment='最新价（f2字段映射）')  # 映射f2
    change_pct = Column(DECIMAL(8, 4), comment='涨跌幅%（f3字段映射）')  # 映射f3

    # 系统字段
    gmt_create = Column(DateTime, nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"),
                        comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='修改时间')


"""
CREATE TABLE constituent_stocks (
    -- 主键
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    
    -- 证券基础信息
    SECUCODE VARCHAR(20) NOT NULL COMMENT '证券全代码（交易所后缀）',
    SECURITY_CODE VARCHAR(10) NOT NULL COMMENT '证券简码',
    TYPE VARCHAR(2) NOT NULL COMMENT '成分股类型（1=普通股）',
    SECURITY_NAME_ABBR VARCHAR(50) NOT NULL COMMENT '证券简称',
    
    -- 行情数据
    CLOSE_PRICE DECIMAL(12,4) COMMENT '收盘价（元）',
    
    -- 公司特征
    INDUSTRY VARCHAR(20) COMMENT '所属行业',
    REGION VARCHAR(10) COMMENT '所属地区',
    WEIGHT DECIMAL(8,4) COMMENT '指数权重（%）',
    
    -- 财务指标
    EPS DECIMAL(8,4) COMMENT '每股收益（元）',
    BPS DECIMAL(12,4) COMMENT '每股净资产（元）',
    ROE DECIMAL(8,4) NULL COMMENT '净资产收益率%（可能为空）',
    
    -- 股本数据（单位：亿股）
    TOTAL_SHARES DECIMAL(18,4) COMMENT '总股本',
    FREE_SHARES DECIMAL(18,4) COMMENT '流通股本',
    FREE_CAP DECIMAL(18,4) COMMENT '流通市值（亿元）',
    
    -- 行情映射字段
    latest_price DECIMAL(12,4) COMMENT '最新价（f2字段映射）',
    change_pct DECIMAL(8,4) COMMENT '涨跌幅%（f3字段映射）',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
    
    -- 索引
    PRIMARY KEY (id),
    INDEX idx_security_type (SECUCODE, TYPE),
    INDEX idx_industry (INDUSTRY),
    INDEX idx_security_code (SECURITY_CODE),
    INDEX idx_secucode (SECUCODE)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='指数成分股数据表';
"""
