from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base


class EodMarketData(Base):
    __tablename__ = 'eod_market_data'
    __table_args__ = (
        Index('idx_symbol', 'symbol'),  # 证券代码的复合索引
        {'comment': 'End-of-Day市场数据（含原始字段映射）'}
    )

    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')

    # 原始字段映射（保留原始f编号）
    ranking = Column(BIGINT(8), comment='排名序号（原始字段f1）')
    latest_price = Column(DECIMAL(12, 4), comment='最新价（原始字段f2）单位：元')
    change_pct = Column(DECIMAL(8, 4), comment='涨跌幅%（原始字段f3）')
    change_amt = Column(DECIMAL(12, 4), comment='涨跌额（原始字段f4）单位：元')
    volume = Column(BIGINT(20), comment='成交量（原始字段f5）单位：手')
    turnover = Column(DECIMAL(18, 4), comment='成交额（原始字段f6）单位：元')
    amplitude = Column(DECIMAL(8, 4), comment='振幅%（原始字段f7）')
    turnover_rate = Column(DECIMAL(8, 4), comment='换手率%（原始字段f8）')
    pe_ratio = Column(DECIMAL(12, 4), comment='市盈率（原始字段f9）')
    volume_ratio = Column(DECIMAL(8, 2), nullable=True, comment='量比（原始字段f10，可能为空）')
    symbol = Column(String(20), nullable=False, comment='股票代码（原始字段f12）')
    market_type = Column(TINYINT(2), comment='市场类型编码（原始字段f13）')
    name = Column(String(50), comment='证券简称（原始字段f14）')
    high = Column(DECIMAL(12, 4), comment='最高价（原始字段f15）单位：元')
    low = Column(DECIMAL(12, 4), comment='最低价（原始字段f16）单位：元')
    open = Column(DECIMAL(12, 4), comment='今开价（原始字段f17）单位：元')
    prev_close = Column(DECIMAL(12, 4), comment='昨收价（原始字段f18）单位：元')

    # 未映射原始字段
    f23 = Column(DECIMAL(12, 4), comment='保留字段f23（待定义用途）')
    f152 = Column(DECIMAL(12, 4), comment='保留字段f152（待定义用途）')

    # 系统字段
    gmt_create = Column(DateTime, nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"),
                        comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='修改时间')

    @classmethod
    def convert_data(self):
        # 封装一些转化数据类型的方法，有些数据进来的时候可能不太一样
        pass


"""
CREATE TABLE eod_market_data (
    -- 主键
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    
    -- 原始字段映射（保留f编号）
    ranking BIGINT(8) COMMENT '排名序号（原始字段f1）',
    latest_price DECIMAL(12,4) COMMENT '最新价（原始字段f2）单位：元',
    change_pct DECIMAL(8,4) COMMENT '涨跌幅%（原始字段f3）',
    change_amt DECIMAL(12,4) COMMENT '涨跌额（原始字段f4）单位：元',
    volume BIGINT(20) COMMENT '成交量（原始字段f5）单位：手',
    turnover DECIMAL(18,4) COMMENT '成交额（原始字段f6）单位：元',
    amplitude DECIMAL(8,4) COMMENT '振幅%（原始字段f7）',
    turnover_rate DECIMAL(8,4) COMMENT '换手率%（原始字段f8）',
    pe_ratio DECIMAL(12,4) COMMENT '市盈率（原始字段f9）',
    volume_ratio DECIMAL(8,2) NULL COMMENT '量比（原始字段f10，可能为空）',
    symbol VARCHAR(20) NOT NULL COMMENT '股票代码（原始字段f12）',
    market_type TINYINT(2) COMMENT '市场类型编码（原始字段f13）',
    name VARCHAR(50) COMMENT '证券简称（原始字段f14）',
    high DECIMAL(12,4) COMMENT '最高价（原始字段f15）单位：元',
    low DECIMAL(12,4) COMMENT '最低价（原始字段f16）单位：元',
    open DECIMAL(12,4) COMMENT '今开价（原始字段f17）单位：元',
    prev_close DECIMAL(12,4) COMMENT '昨收价（原始字段f18）单位：元',
    
    -- 未映射原始字段
    f23 DECIMAL(12,4) COMMENT '保留字段f23（待定义用途）',
    f152 DECIMAL(12,4) COMMENT '保留字段f152（待定义用途）',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
    
    -- 索引
    PRIMARY KEY (id),
    INDEX idx_symbol (symbol),
    INDEX idx_name (name),
    INDEX idx_market_type (market_type),
    INDEX idx_latest_price (latest_price),
    INDEX idx_change_pct (change_pct),
    INDEX idx_turnover (turnover)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='End-of-Day市场数据（含原始字段映射）';
"""