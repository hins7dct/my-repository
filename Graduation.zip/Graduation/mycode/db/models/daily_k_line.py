from sqlalchemy import Column, String, DateTime, Index, text, Date, Enum
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base
import enum


class FrequencyType(enum.Enum):
    """K线频率类型"""
    DAY = 'day'  # 日线
    MIN5 = 'min5'  # 5分钟线
    MIN30 = 'min30'  # 30分钟线

'2019-11-06,34.35,30.61,34.35,29.85,154579,500523276.00,18.49,25.76,6.27,75.94'
class DailyKLine(Base):
    __tablename__ = 'k_line_data'
    __table_args__ = (
        Index('idx_stock_date_freq', 'stock_id', 'trade_date', 'frequency'),  # 复合索引
        Index('idx_date_freq', 'trade_date', 'frequency'),  # 日期+频率索引
        {'comment': '证券K线数据（支持多频率及复权）'}
    )

    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')

    # 证券标识
    stock_id = Column(String(10), nullable=False, comment='证券代码（如：300750.SZ）')

    # 行情数据
    trade_date = Column(DateTime, nullable=False, comment='交易时间')  # 因为频率不同所以数据的格式相应也会不太一样
    frequency = Column(Enum(FrequencyType), nullable=False, default=FrequencyType.DAY, comment='K线频率')

    # 默认存储不复权数据
    open_price = Column(DECIMAL(12, 4), comment='开盘价（元）')
    close_price = Column(DECIMAL(12, 4), comment='收盘价（元）')
    high_price = Column(DECIMAL(12, 4), comment='最高价（元）')
    low_price = Column(DECIMAL(12, 4), comment='最低价（元）')

    # 复权因子 - 用于计算不同复权方式的价格
    adjust_factor = Column(DECIMAL(12, 6), nullable=False, default=1.0, comment='复权因子')

    # 量能指标
    volume = Column(BIGINT(20), comment='成交量（手）')   # 也许会存在小数，但问题不大
    turnover = Column(DECIMAL(18, 4), comment='成交额（元）')

    # 估值指标
    change_pct = Column(DECIMAL(8, 4), comment='涨跌幅（%）')
    pe_ratio = Column(DECIMAL(12, 4), comment='市盈率（PE）')
    pb_ratio = Column(DECIMAL(12, 4), comment='市净率（PB）')
    market_cap = Column(DECIMAL(18, 4), comment='总市值（亿元）')

    # 系统字段
    gmt_create = Column(DateTime, nullable=False,
                        server_default=text("CURRENT_TIMESTAMP"),
                        comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='修改时间')

    def convert_data(self):
        # 封装一些转化数据类型的方法，有些数据进来的时候可能不太一样
        pass


"""
CREATE TABLE k_line_data (
    -- 主键
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    
    -- 证券标识
    stock_id VARCHAR(10) NOT NULL COMMENT '证券代码（如：300750.SZ）',
    
    -- 行情数据
    trade_date DATETIME NOT NULL COMMENT '交易时间',
    frequency ENUM('day','min5','min30') NOT NULL DEFAULT 'day' COMMENT 'K线频率',
    
    -- 价格数据（默认不复权）
    open_price DECIMAL(12,4) COMMENT '开盘价（元）',
    close_price DECIMAL(12,4) COMMENT '收盘价（元）',
    high_price DECIMAL(12,4) COMMENT '最高价（元）',
    low_price DECIMAL(12,4) COMMENT '最低价（元）',
    
    -- 复权因子
    adjust_factor DECIMAL(12,6) NOT NULL DEFAULT 1.000000 COMMENT '复权因子',
    
    -- 量能指标
    volume BIGINT(20) COMMENT '成交量（手）',
    turnover DECIMAL(18,4) COMMENT '成交额（元）',
    
    -- 估值指标
    change_pct DECIMAL(8,4) COMMENT '涨跌幅（%）',
    pe_ratio DECIMAL(12,4) COMMENT '市盈率（PE）',
    pb_ratio DECIMAL(12,4) COMMENT '市净率（PB）',
    market_cap DECIMAL(18,4) COMMENT '总市值（亿元）',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
    
    -- 索引
    PRIMARY KEY (id),
    UNIQUE KEY uk_stock_date_freq (stock_id, trade_date, frequency),
    INDEX idx_stock_date_freq (stock_id, trade_date, frequency),
    INDEX idx_date_freq (trade_date, frequency),
    INDEX idx_stock_id (stock_id),
    INDEX idx_trade_date (trade_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='证券K线数据（支持多频率及复权）';
"""
