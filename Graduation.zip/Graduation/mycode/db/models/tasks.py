from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base


class Tasks(Base):  # 任务类型，大方向上分定时任务和刚授权进来的爬取的较长的任务
    __tablename__ = 'task'
    __table_args__ = (
        Index('idx_task_type_active', 'task_type', 'is_active'),
        {'comment': '任务类型表'}
    )
    id = Column(INTEGER(10), primary_key=True, comment='自增id')
    task_type = Column(String(30), nullable=False, server_default="''", comment='任务类型')
    length = Column(INTEGER(2), nullable=False, server_default=text("'1'"), comment='拉取时间段(天)，最多三十天')
    interval = Column(INTEGER(11), nullable=False, server_default=text("'999999999'"), comment='任务间隔（秒）')
    is_active = Column(TINYINT(4), default=True, comment="是否启用该任务类型")
    task_start = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"),
                        comment='任务开始时间')
    gmt_create = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"), comment='数据创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='数据更新时间')

"""
CREATE TABLE task (
    -- 主键
    id INT(10) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
    
    -- 任务类型配置
    task_type TINYINT(4) NOT NULL DEFAULT 0 COMMENT '任务类型（0=定时任务 1=授权爬取任务 2=紧急补数任务 3=系统维护任务）',
    length INT(2) NOT NULL DEFAULT 1 COMMENT '拉取时间段(天)，范围1-30天',
    interval INT(11) NOT NULL DEFAULT 999999999 COMMENT '任务间隔（秒，默认31年表示单次任务）',
    is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用（0=禁用 1=启用）',
    
    -- 时间控制
    task_start DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '任务开始时间',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据更新时间',
    
    -- 索引
    PRIMARY KEY (id),
    INDEX idx_task_type_active (task_type, is_active),
    INDEX idx_task_start (task_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务类型配置表（定时任务/授权爬取任务）';
"""
