from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base


class BalanceSheet(Base):
    __tablename__ = 'balance_sheet'
    __table_args__ = (
        Index('idx_security_report', 'SECUCODE', 'REPORT_DATE'),  # 复合索引
        {'comment': '企业资产负债表 - '}
    )

    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')
    # 证券基础信息
    SECUCODE = Column(String(20), nullable=False, comment='证券全代码（含交易所后缀）')
    SECURITY_CODE = Column(String(10), nullable=False, comment='证券简码')
    INDUSTRY_CODE = Column(String(10), nullable=False, comment='行业编码')
    ORG_CODE = Column(String(20), nullable=False, comment='组织机构代码')
    SECURITY_NAME_ABBR = Column(String(50), nullable=False, comment='证券简称')
    INDUSTRY_NAME = Column(String(30), nullable=False, comment='行业名称')
    MARKET = Column(String(10), nullable=False, comment='上市市场标识（如kcb=科创板）')
    SECURITY_TYPE_CODE = Column(String(10), nullable=False, comment='证券类型编码')
    TRADE_MARKET_CODE = Column(String(20), nullable=False, comment='交易市场编码')
    # 报告属性
    DATE_TYPE_CODE = Column(String(3), nullable=False, comment='日期类型编码（004=季报）')
    REPORT_TYPE_CODE = Column(String(3), nullable=False, comment='报告类型编码（001=合并报表）')
    DATA_STATE = Column(String(2), nullable=False, comment='数据状态（2=已审计）')
    NOTICE_DATE = Column(DateTime, nullable=False, comment='公告发布时间')
    REPORT_DATE = Column(DateTime, nullable=False, comment='报告期截止日')
    # 主要财务指标（单位：元）
    TOTAL_ASSETS = Column(BIGINT(20), comment='总资产')
    FIXED_ASSET = Column(BIGINT(20), comment='固定资产')
    MONETARYFUNDS = Column(BIGINT(20), comment='货币资金')
    MONETARYFUNDS_RATIO = Column(DECIMAL(20, 4), comment='货币资金占比(%)')
    ACCOUNTS_RECE = Column(BIGINT(20), comment='应收账款')
    ACCOUNTS_RECE_RATIO = Column(DECIMAL(20, 4), comment='应收账款占比(%)')
    INVENTORY = Column(BIGINT(20), comment='存货')
    INVENTORY_RATIO = Column(DECIMAL(20, 4), comment='存货占比(%)')
    TOTAL_LIABILITIES = Column(BIGINT(20), comment='总负债')
    ACCOUNTS_PAYABLE = Column(BIGINT(20), comment='应付账款')
    ACCOUNTS_PAYABLE_RATIO = Column(DECIMAL(20, 4), comment='应付账款占比(%)')
    ADVANCE_RECEIVABLES = Column(BIGINT(20), comment='预收款项')
    ADVANCE_RECEIVABLES_RATIO = Column(DECIMAL(20, 4), comment='预收款项占比(%)')
    TOTAL_EQUITY = Column(BIGINT(20), comment='所有者权益合计')
    TOTAL_EQUITY_RATIO = Column(DECIMAL(20, 4), comment='所有者权益占比(%)')
    TOTAL_ASSETS_RATIO = Column(DECIMAL(20, 4), comment='总资产占比变化(%)')
    TOTAL_LIAB_RATIO = Column(DECIMAL(20, 4), comment='总负债占比变化(%)')
    CURRENT_RATIO = Column(DECIMAL(20, 4), comment='流动比率(%)')
    DEBT_ASSET_RATIO = Column(DECIMAL(20, 4), comment='资产负债率(%)')
    # 可空字段（原始数据存在null值）
    CASH_DEPOSIT_PBC = Column(BIGINT(20), nullable=True, comment='存放中央银行款项')
    CDP_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='存放中央银行款项占比(%)')
    LOAN_ADVANCE = Column(BIGINT(20), nullable=True, comment='发放贷款及垫款')
    LOAN_ADVANCE_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='贷款及垫款占比(%)')
    AVAILABLE_SALE_FINASSET = Column(BIGINT(20), nullable=True, comment='可供出售金融资产')
    ASF_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='可供出售金融资产占比(%)')
    LOAN_PBC = Column(BIGINT(20), nullable=True, comment='向中央银行借款')
    LOAN_PBC_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='央行借款占比(%)')
    ACCEPT_DEPOSIT = Column(BIGINT(20), nullable=True, comment='吸收存款')
    ACCEPT_DEPOSIT_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='吸收存款占比(%)')
    SELL_REPO_FINASSET = Column(BIGINT(20), nullable=True, comment='卖出回购金融资产款')
    SRF_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='卖出回购金融资产款占比(%)')
    SETTLE_EXCESS_RESERVE = Column(BIGINT(20), nullable=True, comment='结算备付金')
    SER_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='结算备付金占比(%)')
    BORROW_FUND = Column(BIGINT(20), nullable=True, comment='拆入资金')
    BORROW_FUND_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='拆入资金占比(%)')
    AGENT_TRADE_SECURITY = Column(BIGINT(20), nullable=True, comment='代理买卖证券款')
    ATS_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='代理买卖证券款占比(%)')
    PREMIUM_RECE = Column(BIGINT(20), nullable=True, comment='应收保费')
    PREMIUM_RECE_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='应收保费占比(%)')
    SHORT_LOAN = Column(BIGINT(20), nullable=True, comment='短期借款')
    SHORT_LOAN_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='短期借款占比(%)')
    ADVANCE_PREMIUM = Column(BIGINT(20), nullable=True, comment='预收保费')
    ADVANCE_PREMIUM_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='预收保费占比(%)')

    # 系统字段
    gmt_create = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"), comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='数据更新时间')

"""
CREATE TABLE balance_sheet (
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    SECUCODE VARCHAR(20) NOT NULL COMMENT '证券全代码（含交易所后缀）',
    SECURITY_CODE VARCHAR(10) NOT NULL COMMENT '证券简码',
    INDUSTRY_CODE VARCHAR(10) NOT NULL COMMENT '行业编码',
    ORG_CODE VARCHAR(20) NOT NULL COMMENT '组织机构代码',
    SECURITY_NAME_ABBR VARCHAR(50) NOT NULL COMMENT '证券简称',
    INDUSTRY_NAME VARCHAR(30) NOT NULL COMMENT '行业名称',
    MARKET VARCHAR(10) NOT NULL COMMENT '上市市场标识（如kcb=科创板）',
    SECURITY_TYPE_CODE VARCHAR(10) NOT NULL COMMENT '证券类型编码',
    TRADE_MARKET_CODE VARCHAR(20) NOT NULL COMMENT '交易市场编码',
    DATE_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '日期类型编码（004=季报）',
    REPORT_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '报告类型编码（001=合并报表）',
    DATA_STATE VARCHAR(2) NOT NULL COMMENT '数据状态（2=已审计）',
    NOTICE_DATE DATETIME NOT NULL COMMENT '公告发布时间',
    REPORT_DATE DATETIME NOT NULL COMMENT '报告期截止日',
    TOTAL_ASSETS BIGINT(20) COMMENT '总资产',
    FIXED_ASSET BIGINT(20) COMMENT '固定资产',
    MONETARYFUNDS BIGINT(20) COMMENT '货币资金',
    MONETARYFUNDS_RATIO DECIMAL(20,4) COMMENT '货币资金占比(%)',
    ACCOUNTS_RECE BIGINT(20) COMMENT '应收账款',
    ACCOUNTS_RECE_RATIO DECIMAL(20,4) COMMENT '应收账款占比(%)',
    INVENTORY BIGINT(20) COMMENT '存货',
    INVENTORY_RATIO DECIMAL(20,4) COMMENT '存货占比(%)',
    TOTAL_LIABILITIES BIGINT(20) COMMENT '总负债',
    ACCOUNTS_PAYABLE BIGINT(20) COMMENT '应付账款',
    ACCOUNTS_PAYABLE_RATIO DECIMAL(20,4) COMMENT '应付账款占比(%)',
    ADVANCE_RECEIVABLES BIGINT(20) COMMENT '预收款项',
    ADVANCE_RECEIVABLES_RATIO DECIMAL(20,4) COMMENT '预收款项占比(%)',
    TOTAL_EQUITY BIGINT(20) COMMENT '所有者权益合计',
    TOTAL_EQUITY_RATIO DECIMAL(20,4) COMMENT '所有者权益占比(%)',
    TOTAL_ASSETS_RATIO DECIMAL(20,4) COMMENT '总资产占比变化(%)',
    TOTAL_LIAB_RATIO DECIMAL(20,4) COMMENT '总负债占比变化(%)',
    CURRENT_RATIO DECIMAL(20,4) COMMENT '流动比率(%)',
    DEBT_ASSET_RATIO DECIMAL(20,4) COMMENT '资产负债率(%)',
    CASH_DEPOSIT_PBC BIGINT(20) NULL COMMENT '存放中央银行款项',
    CDP_RATIO DECIMAL(20,4) NULL COMMENT '存放中央银行款项占比(%)',
    LOAN_ADVANCE BIGINT(20) NULL COMMENT '发放贷款及垫款',
    LOAN_ADVANCE_RATIO DECIMAL(20,4) NULL COMMENT '贷款及垫款占比(%)',
    AVAILABLE_SALE_FINASSET BIGINT(20) NULL COMMENT '可供出售金融资产',
    ASF_RATIO DECIMAL(20,4) NULL COMMENT '可供出售金融资产占比(%)',
    LOAN_PBC BIGINT(20) NULL COMMENT '向中央银行借款',
    LOAN_PBC_RATIO DECIMAL(20,4) NULL COMMENT '央行借款占比(%)',
    ACCEPT_DEPOSIT BIGINT(20) NULL COMMENT '吸收存款',
    ACCEPT_DEPOSIT_RATIO DECIMAL(20,4) NULL COMMENT '吸收存款占比(%)',
    SELL_REPO_FINASSET BIGINT(20) NULL COMMENT '卖出回购金融资产款',
    SRF_RATIO DECIMAL(20,4) NULL COMMENT '卖出回购金融资产款占比(%)',
    SETTLE_EXCESS_RESERVE BIGINT(20) NULL COMMENT '结算备付金',
    SER_RATIO DECIMAL(20,4) NULL COMMENT '结算备付金占比(%)',
    BORROW_FUND BIGINT(20) NULL COMMENT '拆入资金',
    BORROW_FUND_RATIO DECIMAL(20,4) NULL COMMENT '拆入资金占比(%)',
    AGENT_TRADE_SECURITY BIGINT(20) NULL COMMENT '代理买卖证券款',
    ATS_RATIO DECIMAL(20,4) NULL COMMENT '代理买卖证券款占比(%)',
    PREMIUM_RECE BIGINT(20) NULL COMMENT '应收保费',
    PREMIUM_RECE_RATIO DECIMAL(20,4) NULL COMMENT '应收保费占比(%)',
    SHORT_LOAN BIGINT(20) NULL COMMENT '短期借款',
    SHORT_LOAN_RATIO DECIMAL(20,4) NULL COMMENT '短期借款占比(%)',
    ADVANCE_PREMIUM BIGINT(20) NULL COMMENT '预收保费',
    ADVANCE_PREMIUM_RATIO DECIMAL(20,4) NULL COMMENT '预收保费占比(%)',
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_secucode_report (SECUCODE, REPORT_DATE, REPORT_TYPE_CODE),
    INDEX idx_security_report (SECUCODE, REPORT_DATE),
    INDEX idx_report_date (REPORT_DATE)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='企业资产负债表';
"""