from sqlalchemy import Column, String, DateTime, Index, text, Date
from sqlalchemy.dialects.mysql import INTEGER, BIGINT, TINYINT, DECIMAL
from mycode.db.database import Base


class IncomeStatement(Base):
    __tablename__ = 'income_statement'
    __table_args__ = (
        Index('idx_income_security_report', 'SECUCODE', 'REPORT_DATE'),  # 证券代码+报告期复合索引
        {'comment': '企业利润表'}
    )

    # 主键
    id = Column(BIGINT(20), primary_key=True, autoincrement=True, comment='自增主键')

    # 证券基础信息（与资产负债表保持一致）
    SECUCODE = Column(String(20), nullable=False, comment='证券全代码（含交易所后缀）')
    SECURITY_CODE = Column(String(10), nullable=False, comment='证券简码')
    INDUSTRY_CODE = Column(String(10), nullable=False, comment='行业编码')
    ORG_CODE = Column(String(20), nullable=False, comment='组织机构代码')
    SECURITY_NAME_ABBR = Column(String(50), nullable=False, comment='证券简称')
    INDUSTRY_NAME = Column(String(30), nullable=False, comment='行业名称')
    MARKET = Column(String(10), nullable=False, comment='上市市场标识（kcb=科创板）')
    SECURITY_TYPE_CODE = Column(String(10), nullable=False, comment='证券类型编码')
    TRADE_MARKET_CODE = Column(String(20), nullable=False, comment='交易市场编码')

    # 报告属性
    DATE_TYPE_CODE = Column(String(3), nullable=False, comment='日期类型编码（004=季报）')
    REPORT_TYPE_CODE = Column(String(3), nullable=False, comment='报告类型编码（001=合并报表）')
    DATA_STATE = Column(String(2), nullable=False, comment='数据状态（2=已审计）')
    NOTICE_DATE = Column(DateTime, nullable=False, comment='公告发布时间')
    REPORT_DATE = Column(DateTime, nullable=False, comment='报告期截止日')

    # 核心利润指标（单位：元）
    PARENT_NETPROFIT = Column(BIGINT(20), comment='归属于母公司净利润')
    TOTAL_OPERATE_INCOME = Column(BIGINT(20), comment='营业总收入')
    TOTAL_OPERATE_COST = Column(BIGINT(20), comment='营业总成本')
    TOE_RATIO = Column(DECIMAL(20, 4), comment='营业总成本占比(%)')
    OPERATE_COST = Column(BIGINT(20), comment='营业成本')
    OPERATE_EXPENSE = Column(BIGINT(20), comment='营业支出')
    OPERATE_EXPENSE_RATIO = Column(DECIMAL(20, 4), comment='营业支出占比(%)')
    SALE_EXPENSE = Column(BIGINT(20), comment='销售费用')
    MANAGE_EXPENSE = Column(BIGINT(20), comment='管理费用')
    FINANCE_EXPENSE = Column(BIGINT(20), comment='财务费用（负值表示收益）')
    OPERATE_PROFIT = Column(BIGINT(20), comment='营业利润')
    TOTAL_PROFIT = Column(BIGINT(20), comment='利润总额')
    INCOME_TAX = Column(BIGINT(20), comment='所得税费用')

    # 特殊行业字段（允许空值）
    OPERATE_INCOME = Column(BIGINT(20), nullable=True, comment='已赚保费（保险行业专用）')
    INTEREST_NI = Column(BIGINT(20), nullable=True, comment='利息净收入（金融行业）')
    INTEREST_NI_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='利息净收入占比(%)')
    FEE_COMMISSION_NI = Column(BIGINT(20), nullable=True, comment='手续费及佣金净收入')
    FCN_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='手续费及佣金净收入占比(%)')
    OPERATE_TAX_ADD = Column(BIGINT(20), nullable=True, comment='税金及附加')
    MANAGE_EXPENSE_BANK = Column(BIGINT(20), nullable=True, comment='业务及管理费（银行专用）')
    FCN_CALCULATE = Column(BIGINT(20), nullable=True, comment='手续费及佣金支出（计算项）')
    INTEREST_NI_CALCULATE = Column(BIGINT(20), nullable=True, comment='利息支出（计算项）')
    EARNED_PREMIUM = Column(BIGINT(20), nullable=True, comment='已赚保费（保险行业）')
    EARNED_PREMIUM_RATIO = Column(DECIMAL(20, 4), nullable=True, comment='已赚保费占比(%)')
    INVEST_INCOME = Column(BIGINT(20), nullable=True, comment='投资收益')
    SURRENDER_VALUE = Column(BIGINT(20), nullable=True, comment='退保金（保险行业）')
    COMPENSATE_EXPENSE = Column(BIGINT(20), nullable=True, comment='赔付支出（保险行业）')

    # 比率指标
    TOI_RATIO = Column(DECIMAL(20, 4), comment='营业总收入占比变化(%)')
    OPERATE_PROFIT_RATIO = Column(DECIMAL(20, 4), comment='营业利润率(%)')
    PARENT_NETPROFIT_RATIO = Column(DECIMAL(20, 4), comment='归母净利润率(%)')
    DEDUCT_PARENT_NETPROFIT = Column(BIGINT(20), comment='扣除非经常性损益后的净利润')
    DPN_RATIO = Column(DECIMAL(20, 4), comment='扣非净利润率(%)')

    # 系统字段
    gmt_create = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"), comment='创建时间')
    gmt_modified = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
                          comment='数据更新时间')

    def add(self):
        pass


"""
CREATE TABLE income_statement (
    -- 主键
    id BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    
    -- 证券基础信息
    SECUCODE VARCHAR(20) NOT NULL COMMENT '证券全代码（含交易所后缀）',
    SECURITY_CODE VARCHAR(10) NOT NULL COMMENT '证券简码',
    INDUSTRY_CODE VARCHAR(10) NOT NULL COMMENT '行业编码',
    ORG_CODE VARCHAR(20) NOT NULL COMMENT '组织机构代码',
    SECURITY_NAME_ABBR VARCHAR(50) NOT NULL COMMENT '证券简称',
    INDUSTRY_NAME VARCHAR(30) NOT NULL COMMENT '行业名称',
    MARKET VARCHAR(10) NOT NULL COMMENT '上市市场标识（kcb=科创板）',
    SECURITY_TYPE_CODE VARCHAR(10) NOT NULL COMMENT '证券类型编码',
    TRADE_MARKET_CODE VARCHAR(20) NOT NULL COMMENT '交易市场编码',
    
    -- 报告属性
    DATE_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '日期类型编码（004=季报）',
    REPORT_TYPE_CODE VARCHAR(3) NOT NULL COMMENT '报告类型编码（001=合并报表）',
    DATA_STATE VARCHAR(2) NOT NULL COMMENT '数据状态（2=已审计）',
    NOTICE_DATE DATETIME NOT NULL COMMENT '公告发布时间',
    REPORT_DATE DATETIME NOT NULL COMMENT '报告期截止日',
    
    -- 核心利润指标（单位：元）
    PARENT_NETPROFIT BIGINT(20) COMMENT '归属于母公司净利润',
    TOTAL_OPERATE_INCOME BIGINT(20) COMMENT '营业总收入',
    TOTAL_OPERATE_COST BIGINT(20) COMMENT '营业总成本',
    TOE_RATIO DECIMAL(20,4) COMMENT '营业总成本占比(%)',
    OPERATE_COST BIGINT(20) COMMENT '营业成本',
    OPERATE_EXPENSE BIGINT(20) COMMENT '营业支出',
    OPERATE_EXPENSE_RATIO DECIMAL(20,4) COMMENT '营业支出占比(%)',
    SALE_EXPENSE BIGINT(20) COMMENT '销售费用',
    MANAGE_EXPENSE BIGINT(20) COMMENT '管理费用',
    FINANCE_EXPENSE BIGINT(20) COMMENT '财务费用（负值表示收益）',
    OPERATE_PROFIT BIGINT(20) COMMENT '营业利润',
    TOTAL_PROFIT BIGINT(20) COMMENT '利润总额',
    INCOME_TAX BIGINT(20) COMMENT '所得税费用',
    
    -- 特殊行业字段（允许空值）
    OPERATE_INCOME BIGINT(20) NULL COMMENT '已赚保费（保险行业专用）',
    INTEREST_NI BIGINT(20) NULL COMMENT '利息净收入（金融行业）',
    INTEREST_NI_RATIO DECIMAL(20,4) NULL COMMENT '利息净收入占比(%)',
    FEE_COMMISSION_NI BIGINT(20) NULL COMMENT '手续费及佣金净收入',
    FCN_RATIO DECIMAL(20,4) NULL COMMENT '手续费及佣金净收入占比(%)',
    OPERATE_TAX_ADD BIGINT(20) NULL COMMENT '税金及附加',
    MANAGE_EXPENSE_BANK BIGINT(20) NULL COMMENT '业务及管理费（银行专用）',
    FCN_CALCULATE BIGINT(20) NULL COMMENT '手续费及佣金支出（计算项）',
    INTEREST_NI_CALCULATE BIGINT(20) NULL COMMENT '利息支出（计算项）',
    EARNED_PREMIUM BIGINT(20) NULL COMMENT '已赚保费（保险行业）',
    EARNED_PREMIUM_RATIO DECIMAL(20,4) NULL COMMENT '已赚保费占比(%)',
    INVEST_INCOME BIGINT(20) NULL COMMENT '投资收益',
    SURRENDER_VALUE BIGINT(20) NULL COMMENT '退保金（保险行业）',
    COMPENSATE_EXPENSE BIGINT(20) NULL COMMENT '赔付支出（保险行业）',
    
    -- 比率指标
    TOI_RATIO DECIMAL(20,4) COMMENT '营业总收入占比变化(%)',
    OPERATE_PROFIT_RATIO DECIMAL(20,4) COMMENT '营业利润率(%)',
    PARENT_NETPROFIT_RATIO DECIMAL(20,4) COMMENT '归母净利润率(%)',
    DEDUCT_PARENT_NETPROFIT BIGINT(20) COMMENT '扣除非经常性损益后的净利润',
    DPN_RATIO DECIMAL(20,4) COMMENT '扣非净利润率(%)',
    
    -- 系统字段
    gmt_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    gmt_modified DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据更新时间',
    
    -- 索引
    PRIMARY KEY (id),
    INDEX idx_income_security_report (SECUCODE, REPORT_DATE),
    INDEX idx_report_date (REPORT_DATE),
    INDEX idx_industry_code (INDUSTRY_CODE),
    INDEX idx_market (MARKET),
    INDEX idx_report_type (REPORT_TYPE_CODE),
    INDEX idx_total_operate_income (TOTAL_OPERATE_INCOME),
    INDEX idx_parent_netprofit (PARENT_NETPROFIT)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='企业利润表';
"""
