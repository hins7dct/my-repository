from sqlalchemy.orm import Session
from sqlalchemy import insert, select, update, func, and_
from mycode.db.db_operation.base_dboperation import BaseCRUD
from mycode.db.models.balance_sheet import BalanceSheet
from mycode.db.models.cash_flow import CashFlowStatement
from mycode.db.models.income_statement import IncomeStatement


# 创建一个通用的财务报表基类
class ReportBaseCRUD(BaseCRUD):
    """财务报表基础操作类，实现通用的插入、更新和查询方法"""

    def insert_data(self, session: Session, data_list: list):
        """插入or更新数据"""
        if not data_list:
            return
        try:
            REPORT_DATE = data_list[0].get('RREPORT_DATE')
            SECURITY_CODE = data_list[0].get('SECURITY_CODE')
            if not self.is_existing_data(session, SECURITY_CODE):
                # 不存在这个股票数据，全部插入
                stmt = insert(self.model.__table__).values(data_list)
            else:
                if REPORT_DATE >= self.get_latest_report_date(session, SECURITY_CODE, REPORT_DATE):
                    # 存在这个股票数据，并且报告日期大于等于最新报告日期，则插入
                    stmt = insert(self.model.__table__).values(data_list[0])
                    session.execute(stmt)
                    session.commit()
                else:
                    # 存在这个股票数据，并且报告日期小于等于最新报告日期，则更新gmt_modified等无关字段
                    stmt = update(self.model).where(
                        self.model.SECURITY_CODE == SECURITY_CODE,
                        self.model.REPORT_DATE == REPORT_DATE
                    ).values(gmt_modified=func.now())
                    session.execute(stmt)
                    session.commit()
        except Exception as e:
            session.rollback()
            raise e

    def get_latest_report_date(self, session: Session, stock_id: str, report_type: str):
        """获取最新报告日期"""
        query = select(func.max(self.model.REPORT_DATE)).where(
            self.model.SECURITY_CODE == stock_id,
            self.model.REPORT_TYPE == report_type
        )
        return session.scalar(query)

    def is_existing_data(self, session: Session, stock_id: str):
        """判断是否存在数据"""
        query = select(self.model).where(
            self.model.SECURITY_CODE == stock_id,
        )
        if query:
            return True
        else:
            return False

    def get_data(self, session: Session, stock_id: str, report_date=None, limit: int = 10):
        """获取报表数据"""
        query = select(self.model).where(self.model.SECURITY_CODE == stock_id)

        if report_date:
            query = query.where(self.model.REPORT_DATE == report_date)

        query = query.order_by(self.model.REPORT_DATE.desc()).limit(limit)

        return session.scalars(query).all()


# 以下是各个具体报表的实现类
class BalanceSheetCRUD(ReportBaseCRUD):
    def __init__(self):
        super().__init__(BalanceSheet)

    # 为了保持API兼容性，提供特定的方法名
    def insert_into_balance_sheet(self, session: Session, data_list: list):
        """批量插入资产负债表数据"""
        return self.insert_data(session, data_list)

    def get_balance_sheet(self, session: Session, stock_id: str, report_date=None, limit: int = 10):
        """获取资产负债表数据"""
        return self.get_data(session, stock_id, report_date, limit)


class CashFlowStatementCRUD(ReportBaseCRUD):
    def __init__(self):
        super().__init__(CashFlowStatement)

    # 为了保持API兼容性，提供特定的方法名
    def insert_into_cash_flow(self, session: Session, data_list: list):
        """批量插入现金流量表数据"""
        return self.insert_data(session, data_list)

    def get_cash_flow(self, session: Session, stock_id: str, report_date=None, limit: int = 10):
        """获取现金流量表数据"""
        return self.get_data(session, stock_id, report_date, limit)


class IncomeStatementCRUD(ReportBaseCRUD):
    def __init__(self):
        super().__init__(IncomeStatement)

    # 为了保持API兼容性，提供特定的方法名
    def insert_into_income_statement(self, session: Session, data_list: list):
        """批量插入利润表数据"""
        return self.insert_data(session, data_list)

    def get_income_statement(self, session: Session, stock_id: str, report_date=None, limit: int = 10):
        """获取利润表数据"""
        return self.get_data(session, stock_id, report_date, limit)


if __name__ == '__main__':
    pass