from typing import Any, Type, Generic, TypeVar
from sqlalchemy.orm import Session

ModelType = TypeVar("ModelType")


class BaseCRUD(Generic[ModelType]):
    """通用 CRUD 模板类[3,6](@ref)"""

    def __init__(self, model: Type[ModelType]):
        self.model = model

    def create(self, db: Session, obj_in: dict) -> ModelType:
        """创建记录（自动处理自增ID）[8](@ref)"""
        db_obj = self.model(**obj_in)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def bulk_create(self, db: Session, data_list: list[dict]):
        """批量插入（高性能方案）[6](@ref)"""
        db.execute(
            self.model.__table__.insert(),
            data_list
        )
        db.commit()