from sqlalchemy.orm import Session
from mycode.db.models.all_stocks import StocksInfo
from sqlalchemy import insert
from mycode.db.db_operation.base_dboperation import BaseCRUD


class StockCRUD(BaseCRUD[StocksInfo]):
    def __init__(self):
        super().__init__(StocksInfo)

    def insert_all_stockInfo(self, session: Session, data_list: list):
        """批量插入股票信息"""
        # 示例数据构造
        # data_list = [
        # {"stockId": "001", "name": "腾讯"},
        #  {"stockId": "002", "name": "茅台"}
        # ]
        # 因为股票信息比较少，数量也没有那么多，直接插入，不做分批处理
        if not data_list:
            return
        try:
            for data in data_list:
                if self.is_existing_stockId(session, data.get('stockId')):
                    continue
                else:
                    stmt = insert(self.model.__table__).values(data)
                    session.execute(stmt)
                    session.commit()
        except Exception as e:
            session.rollback()
            raise e

    def get_all_stock_ids(self, session: Session) -> list[str]:
        """获取全部股票ID列表"""
        result = session.query(self.model.stockId).all()
        return [row[0] for row in result]  # 返回纯字符串列表

    def is_existing_stockId(self, session: Session, stock_id: str):
        exist = session.query(self.model).filter(
                self.model.stockId == stock_id
                ).first()
        if exist:
            return True
        else:
            return False