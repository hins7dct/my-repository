from sqlalchemy import create_engine
from all_stocks_dboperation import StockCRUD
from sqlalchemy.orm import Session


engine = create_engine("mysql+pymysql://root:123456@localhost:3306/test")
data_list = [
            {"stockId": "001", "name": "腾讯"},
            {"stockId": "002", "name": "茅台"}
]
with Session(engine) as session:
    StockCRUD.insert_all_stockInfo(data_list)